my ass burns
